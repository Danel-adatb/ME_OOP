package neptun_kod;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		int n = 2;
		Ec[] ceg = new Ec[n];
		
		readFile(ceg);
		outputDatas(ceg);
		
		//Rendez�shez:
			ArrayList<Ec> ceg2 = new ArrayList<Ec>();
			for (int i = 0; i < ceg.length; i++) {
				ceg2.add(ceg[i]);
			}
		//------------
		sort(ceg2);
		most(ceg);
		
		//Keres�
		int keres = ellenorzottInt();
		old(ceg, keres);
	}
	
	public static void old(Ec[] ceg, int keres) {
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		for (int i = 0; i < ceg.length; i++) {
			if(keres > currentDate.getYear() - ceg[i].getYear()) {
				ceg[i].toString();
			} else {
				System.out.println("Nem volt ilyen!");
			}
		}
	}
	
	public static void readFile(Ec[] ceg) {
		boolean ok;
		int arbevetel = 0, ev = 0;
		EnumTev kor = null;
		String nev = null, hely = null;
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader input = new BufferedReader(in);
		
		for (int i = 0; i < ceg.length; i++) {
			do {
				ok = true;
				try {
					//Beolvasott �rt�kek-----------------------------------------
						
					System.out.println((i+1) + " �rbev�tel (alap�rt�khez �ss�n be 0-�t!):");
					arbevetel = Integer.valueOf(input.readLine());
					while(arbevetel < 1000000 && arbevetel != 0) {
						System.out.println("Rossz �rt�k, csak 1milli� feletti!");
						arbevetel = Integer.valueOf(input.readLine());
						}
					if(arbevetel == 0) {
						System.out.println((i+1) + " Tev�kenys�gi k�r:");
						String strng = input.readLine();
						kor = EnumTev.valueOf(strng.toUpperCase());
						
						System.out.println((i+1) + ". N�v:");
						nev = input.readLine();
						
						System.out.println((i+1) + ". Hely:");
						hely = input.readLine();
						
						ceg[i] = new Ec(nev, hely, kor);
					} else {
						System.out.println((i+1) + " Alap�t�s �ve:");
						ev = Integer.valueOf(input.readLine());
						while(ev > currentDate.getYear()) {
							System.out.println("Helyes �vet adjon meg!");
							ev = Integer.valueOf(input.readLine());	
						}
						
						System.out.println((i+1) + " Tev�kenys�gi k�r:");
						String strng = input.readLine();
						kor = EnumTev.valueOf(strng.toUpperCase());
						
						System.out.println((i+1) + ". N�v:");
						nev = input.readLine();
						
						System.out.println((i+1) + ". Hely:");
						hely = input.readLine();

						ceg[i] = new Ec(nev, hely, ev, kor, arbevetel);
					}
					//Beolvasott �rt�kek-----------------------------------------
				} catch (IOException e) {
					e.getMessage();
					ok = false;
				} catch(IllegalArgumentException e) {
					System.out.println("Nem l�tez� tev�kenys�gi k�r!");
					ok = false;
				}
			} while(!ok);
		}
	}
	
	public static void getDatas(Ec[] ceg) {
		boolean ok;
		int arbevetel = 0, ev = 0;
		EnumTev kor = null;
		String nev = null, hely = null;
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader input = new BufferedReader(in);
		
		for (int i = 0; i < ceg.length; i++) {
			do {
				ok = true;
				try {					
					//Beolvasott �rt�kek-----------------------------------------
						
					System.out.println((i+1) + " �rbev�tel (alap�rt�khez �ss�n be 0-�t!):");
					arbevetel = Integer.valueOf(input.readLine());
					while(arbevetel < 1000000 && arbevetel != 0) {
						System.out.println("Rossz �rt�k, csak 1milli� feletti!");
						arbevetel = Integer.valueOf(input.readLine());
						}
					if(arbevetel == 0) {
						System.out.println((i+1) + " Tev�kenys�gi k�r:");
						String strng = input.readLine();
						kor = EnumTev.valueOf(strng.toUpperCase());
						
						System.out.println((i+1) + ". R�kos n�v:");
						nev = input.readLine();
						
						System.out.println((i+1) + ". R�kos geci hely:");
						hely = input.readLine();
						
						ceg[i] = new Ec(nev, hely, kor);
					} else {
						System.out.println((i+1) + " Alap�t�s �ve:");
						ev = Integer.valueOf(input.readLine());
						while(ev > currentDate.getYear()) {
							System.out.println("Helyes �vet adjon meg!");
							ev = Integer.valueOf(input.readLine());	
						}
						
						System.out.println((i+1) + " Tev�kenys�gi k�r:");
						String strng = input.readLine();
						kor = EnumTev.valueOf(strng.toUpperCase());
						
						System.out.println((i+1) + ". R�kos n�v:");
						nev = input.readLine();
						
						System.out.println((i+1) + ". R�kos geci hely:");
						hely = input.readLine();
						
						ceg[i] = new Ec(nev, hely, ev, kor, arbevetel);
					}
					//Beolvasott �rt�kek-----------------------------------------
					
					//Fileb�l val� beolvas�s
					
					/*File file = new File("nevek.txt");
						Scanner scanner;
						String nextLine=null;
						try {
							scanner = new Scanner(file);
							nextLine = scanner.nextLine();
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
						String[] names = nextLine.split(";");
						String nev = null, hely = null;
						
						while(nextLine != null) {
							nev = names[0];
							hely = names[1];
					}*/
				} catch (IOException e) {
					e.getMessage();
					ok = false;
				} catch(IllegalArgumentException e) {
					System.out.println("Nem l�tez� tev�kenys�gi k�r!");
					ok = false;
				}
			} while(!ok);
		}
	}
	
	public static void outputDatas(Ec[] ceg) {
		for (Ec i : ceg) {
			System.out.println(i.toString());
		}
	}
	
	public static void sort(ArrayList<Ec> ceg2) {
		Collections.sort(ceg2);
		System.out.println("\nSorbarendez�s ut�n:");
		for (Ec i : ceg2) {
			System.out.println(i.toString());
		}
	}
	
	public static void most(Ec[] ceg) {
		ArrayList<String> vizsgalt = new ArrayList<String>();
		
		for (Ec i : ceg) {
			String hely = i.getHely();
			
			if(!vizsgalt.contains(hely)) {
				vizsgalt.add(hely);
				System.out.println("\nHely: " + hely + "(" + count(ceg, hely) + " db)");
			}
		}
	}
	
	public static int count(Ec[] ceg, String hely) {
		int number = 0;
		for (Ec i : ceg) {
			if (i.getHely().equals(hely)) {
				number++;
			}
		}
		return number;
	}
	
	public static int ellenorzottInt() {
		Scanner input = new Scanner(System.in);
		int n;
		
		do {
			System.out.println("Adjon meg egy 1-10 k�z� es� sz�mot:");
			while (!input.hasNextInt()) {
				System.out.println("Ez nem egy sz�m!");
				input.next();
			}
			n = input.nextInt();
		} while(n < 0 || n > 10);
		
		return n;
	}

	
}
