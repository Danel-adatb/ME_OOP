package neptun_kod;

public enum EnumTev {
	SWFEJLESZTES, OKTATAS, TANACSADAS;
}
