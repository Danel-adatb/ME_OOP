package neptun_kod;

public class Vallalkozas {
	private String nev;
	private String hely;
	private int ev;
	
	public Vallalkozas(String nev, String hely, int ev) {
		this.nev = nev;
		this.hely = hely;
		this.ev = ev;
	}
	
	public Vallalkozas(String nev, String hely) {
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		this.nev = nev;
		this.hely = hely;
		this.ev = currentDate.getYear();
	}
	
	public String getNev() {
		return nev;
	}
	
	public String getHely() {
		return hely;
	}
	
	public int getYear() {
		return ev;
	}
	
	//---------------------------
	
	public void setNev(String nev) {
		this.nev = nev;
	}
	
	public void setHely(String hely) {
		this.hely = hely;	
	}
	
	public void setEv(int ev) {
		this.ev = ev;
	}
	
	@Override
	public String toString() {
		return "N�v: " + this.nev + ", Sz�khely: " + this.hely + ", Alap�t�s �ve: " + this.ev;
	}
	
}
