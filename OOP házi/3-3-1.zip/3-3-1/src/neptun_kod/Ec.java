package neptun_kod;

public class Ec extends Vallalkozas implements Comparable<Ec>{
	private EnumTev kor;
	private int arbevetel;
	private double adokulcs = 0.16;
	
	public Ec(String nev, String hely, int ev, EnumTev kor, int arbevetel) {
		super(nev, hely, ev);
		
		this.kor = kor;
		this.arbevetel = arbevetel;
	}
	
	public Ec(String nev, String hely, EnumTev kor) {
		
		super(nev, hely);
		
		this.kor = kor;
		this.arbevetel = 1000000;
	}
	
	@Override
	public String toString() {
		return super.toString() + ", Tev�kenys�gi k�r: " + this.kor + ", �rbev�tel: " + this.arbevetel + ", Kisz�m�tott ad�: " + getAdozas(this.adokulcs, this.arbevetel);
	}
	
	public double getAdozas(double adokulcs, int arbevetel) {
		return this.adokulcs * this.arbevetel;
	}
	
	@Override
	public int compareTo(Ec o) {
		return Integer.compare(getAr(), o.getAr());
	}
	
	public static int osszehasonlit(Ec o1, Ec o2) {
		if(o1.arbevetel > o2.arbevetel) {
			return o1.arbevetel;
		}
		
		return o2.arbevetel;
	}
	
	public int getAr() {
		return arbevetel;
	}
	
	public void setAr(int arbevetel) {
		this.arbevetel = arbevetel;
	}
	
	public EnumTev getKor() {
		return kor;
	}
	
	public void setKor(EnumTev kor) {
		this.kor = kor;
	}
	
}
