package hazi_10;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;


public class Test {

	public static void main(String[] args) {
		Examiner[] examiner = new Examiner[2];
		ArrayList<Examiner> examiner2 = new ArrayList<Examiner>();
		
		/*5.)*/
		for (int i = 0; i < examiner.length; i++) {
			examiner[i] = readDatas();
			examiner2.add(examiner[i]);
		}
		
		sortByDate(examiner2);
		
		File file = new File("datas.txt");
		writeIntoFile(file, examiner2);
		
		System.out.println("\nFile-b�l olvasott:");
		ArrayList<String> readFromFile = new ArrayList<String>();
		readFromFile = readFile(file);
		System.out.println(readFromFile);

	}
	
/*1.)*/	public static Examiner readDatas() {
			Examiner examiner = null;
			boolean ok;
			LocalDate date = null;
			
			InputStreamReader input = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(input);
			
			do {
				ok = true;
				try {
					System.out.println("T�rgy neve:");
					String name = br.readLine();
					
					System.out.println("D�tum: (pl: 2000-06-09)");
					String dateUnformed = br.readLine();
						date = LocalDate.parse(dateUnformed);
					
					System.out.println("�rdemjegy:");
					int mark = Integer.valueOf(br.readLine());
					
					examiner = new Examiner(name, date, mark);
					
				} catch (InvalidMarkException ex) {
					System.out.println("Nem l�tez� �rdemjegyet adott meg!");
					ok = false;
				} catch (IOException e) {
					e.getMessage();
					ok = false;
				} catch (DateTimeParseException e) {
					e.getMessage();
					System.out.println("Nem j� form�tum!");
					ok = false;
				}
			} while(!ok);
			
			return examiner;
		}

/*2.)*/ public static void sortByDate(ArrayList<Examiner> examiner2) {
			Collections.sort(examiner2);
			
			for (Examiner i : examiner2) {
				System.out.println(i.toString());
			}
		}

/*3.)*/ public static void writeIntoFile(File file, ArrayList<Examiner> examiner2) {
			try {
				FileWriter fw = new FileWriter(file);
				
				for (Examiner i : examiner2) {
					fw.write(i + "\n");
				}
				fw.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}

/*4.)*/ public static ArrayList<String> readFile(File file) {
			ArrayList<String> list = new ArrayList<String>();
			
			try (FileReader fr = new FileReader(file);
				 BufferedReader reader = new BufferedReader(fr)) {
				String line;
				
				while ((line = reader.readLine()) != null) {
					list.add(line);
				}
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
			
			return list;
		}

}
