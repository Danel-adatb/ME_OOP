package hazi_10;

import java.time.LocalDate;

public class Examiner implements Comparable<Examiner> {
	private String name;
	private LocalDate date;
	private int mark;
	
	public Examiner(String name, LocalDate date, int mark) throws InvalidMarkException {
		super();
		
		this.name = name;
		this.date = date;
		if (mark >= 1 && mark <= 5) {
			this.mark = mark;
		} else {
			throw new InvalidMarkException(mark);
		}
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getMark() {
		return mark;
	}
	
	public void setMark(int mark) {
		this.mark = mark;
	}
	
	public LocalDate getDate() {
		return date;
	}
	
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	@Override
	public String toString() {
		return "Examiner's name: " + name + ", mark: " + mark + ", date: " + date;
	}
	
	@Override
	public int compareTo(Examiner o) {
		return getDate().compareTo(o.getDate());
	}
}
