package hazi_10;

public class InvalidMarkException extends Exception {
	private static final long serialVersionUID = 1L;
	private int invalidMark;
	
	public InvalidMarkException(int invalidMark) {
		this.invalidMark = invalidMark;
	}
	
	public int getInvalidMark() {
		return invalidMark;
	}
}
