package hazi_2020_szabo_dani_xuxejo_05_2;

import java.util.ArrayList;
import java.util.Scanner;

public class Konyv_prog {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("H�ny darab k�nyvet szeretne beolvasni?");
		int n = input.nextInt();
		input.nextLine();

		Konyv[] konyvek = new Konyv[n];

		for (int i = 0; i < konyvek.length; i++) {
			System.out.println((i + 1) + ". K�nyv c�me: ");
			String cim = input.nextLine();
			System.out.println((i + 1) + ". K�nyv szerz�je: ");
			String szerzo = input.nextLine();
			System.out.println((i + 1) + ". K�nyv �ra (0-t �tve alap�rt�ket[2500] kap): ");
			int ar = input.nextInt();
			System.out.println((i + 1) + ". K�nyv oldalainak a sz�ma: ");
			int oldalsz = input.nextInt();
			input.nextLine();

			if (ar == 0) {
				konyvek[i] = new Konyv(cim, szerzo, oldalsz);
			} else {
				konyvek[i] = new Konyv(cim, szerzo, ar, oldalsz);
			}
		}

		kiiratKonyvek(konyvek);

		System.out.println("\nLeghosszabb konyv adatai: " + konyvek[hosszu(konyvek)].toString());

		if (hosszuParos(konyvek) == null) {
			System.out.println("Nincs p�ros k�nyv!");
		} else {
			System.out.println("Leghosszabb P�ROS konyv adatai: " + konyvek[hosszuParos(konyvek)].toString());
		}
		System.out.println();

		szerzoDbszam(konyvek);
		input.close();
	}

	static void kiiratKonyvek(Konyv[] konyvek) {
		for (Konyv konyv : konyvek) {
			System.out.println(konyv.toString());
		}
	}

	static int hosszu(Konyv[] konyvek) {
		int maxindex = 0;

		for (int i = 0; i < konyvek.length; i++) {
			if (konyvek[i].getOldal() > konyvek[maxindex].getOldal()) {
				maxindex = i;
			}
		}

		return maxindex;

	}

	private static Integer hosszuParos(Konyv[] konyvek) {
		Integer index = null;
		Integer maxOldalszam = Integer.MIN_VALUE;
		for (int i = 0; i < konyvek.length; ++i) {
			if (konyvek[i].parosOldal()) {
				if (maxOldalszam < konyvek[i].getOldal()) {
					maxOldalszam = konyvek[i].getOldal();
					index = i;
				}
			}
		}
		return index;
	}

	private static void szerzoDbszam(Konyv[] konyvek) {
		ArrayList<String> vizsgaltSzerzo = new ArrayList<String>();
		for (Konyv konyv : konyvek) {
			String szerzo = konyv.getSzerzo();
			if (!vizsgaltSzerzo.contains(szerzo)) {
				vizsgaltSzerzo.add(szerzo);
				System.out
						.println("Szerz�: " + szerzo + " - " + szerzoKonyvei(konyvek, szerzo) + "db k�nyve jelent meg");
			}
		}
	}

	private static int szerzoKonyvei(Konyv[] konyvek, String szerzo) {
		int numberOfBooks = 0;
		for (Konyv konyv : konyvek) {
			if (konyv.getSzerzo().equals(szerzo)) {
				numberOfBooks++;
			}
		}
		return numberOfBooks;
	}

}
