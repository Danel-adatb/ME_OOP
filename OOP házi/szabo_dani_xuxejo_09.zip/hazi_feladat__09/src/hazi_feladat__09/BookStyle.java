package hazi_feladat__09;

public enum BookStyle {
	CRIME, COOK, OTHER;
}
