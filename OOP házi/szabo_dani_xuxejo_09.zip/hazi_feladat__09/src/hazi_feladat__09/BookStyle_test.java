package hazi_feladat__09;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class BookStyle_test {

	public static void main(String[] args) {
		
		ArrayList<BookWithStyle> tomb = new ArrayList<BookWithStyle>();
		System.out.println("Mennyi k�nyvet szeretne megadni?");
		int size = intReader();
		
		for (int i = 0; i < size; i++) {
			tomb.add(readBook());
		}
		
		System.out.println(tomb.size());
		listArray(tomb);
		System.out.println("\nCOOK st�lus� k�nyvek:");
		CookStyles(tomb);
		
		//-------------------------------------------------------
		
		InputStreamReader instream = new InputStreamReader(System.in);
		BufferedReader input = new BufferedReader(instream);
		
		BookStyle still = null;
		boolean ok = false;
		String strng = null;
		
		System.out.println("\nMelyik st�lust keresi?");
		do {
			try {
				ok = true;
				strng = input.readLine();
				still = BookStyle.valueOf(strng.toUpperCase());
			} catch(IllegalArgumentException e) {
				System.out.println("Nincs ilyen st�lus!");
				ok = false;
			} catch (IOException ex) {
				System.out.println(ex.getMessage());
				ok = false;
			}
		}while(!ok);
		
		System.out.println("\n" + still + " st�lus� k�nyvek: ");
		ArrayList<BookWithStyle> stilusos = whatStyle(tomb, still);
		listArray(stilusos);
		listArraySort(tomb);
	}
	
	public static void listArray(ArrayList<BookWithStyle> tomb) {
		for(BookWithStyle i : tomb) {
			System.out.println(i);
		}
	}

	public static int intReader() {
		InputStreamReader instream = new InputStreamReader(System.in);
		BufferedReader input = new BufferedReader(instream);
		
		int number = 0;
		boolean ok = false;
		
		do {
			try {
				ok = true;
				number = Integer.valueOf(input.readLine());
			} catch (IOException e) {
				System.out.println(e.getMessage());
				ok = false;
			} catch (NumberFormatException ex) {
				System.out.println("Ez nem egy sz�m!");
				ok = false;
			}
		} while(!ok);
		
		return number;
	}
	
	public static BookWithStyle readBook() {
		BookWithStyle bookStyle = null;
		
		InputStreamReader instream = new InputStreamReader(System.in);
		BufferedReader input = new BufferedReader(instream);
		
		String strng;
		boolean ok = false;
		do {
			try {
				ok = true;
				System.out.println("C�m: ");
				String cim = input.readLine();
				System.out.println("Szerz�: ");
				String szerzo = input.readLine();
				System.out.println("�r: ");
				int ar = Integer.valueOf(input.readLine());
				System.out.println("Oldalsz�m: ");
				int oldalsz = Integer.valueOf(input.readLine());
				System.out.println("St�lus: ");
				strng = input.readLine();
				BookStyle style = BookStyle.valueOf(strng.toUpperCase());
				
				bookStyle = new BookWithStyle(cim, szerzo, ar, oldalsz, style);
				
			} catch(IllegalArgumentException e) {
				System.out.println("Nem l�tez� st�lus!");
				ok = false;
			} catch(IOException e) {
				System.out.println(e.getMessage());
			}
		} while(!ok);
		
		return bookStyle;
	}
	
	public static void CookStyles(ArrayList<BookWithStyle> tomb) {
		ArrayList<BookWithStyle> vizsgalt = new ArrayList<BookWithStyle>();

		for (BookWithStyle i : tomb) {
			if (i.getBookStyle().equals(BookStyle.COOK)) {
				vizsgalt.add(i);
			}
		}
		for (BookWithStyle i : vizsgalt) {
			System.out.println(i);
		}
	}
	
	public static ArrayList<BookWithStyle> whatStyle(ArrayList<BookWithStyle> tomb, BookStyle still) {
		ArrayList<BookWithStyle> vizsgalt = new ArrayList<BookWithStyle>();
		
		for (BookWithStyle i : tomb) {
			if(i.getBookStyle().equals(still)) {
				vizsgalt.add(i);
			}
		}
		
		return vizsgalt;
	}
	
	public static void listArraySort(ArrayList<BookWithStyle> tomb) {
		System.out.println("\n1: Oldalsz�m szerinti rendez�s!");
		System.out.println("0: ABC szerinti!");
		
		InputStreamReader instream = new InputStreamReader(System.in);
		BufferedReader input = new BufferedReader(instream);
		
		int number = intReader();
		BookWithStyle[] array = tomb.toArray(new BookWithStyle[0]);
		
		if (number == 1) {
			Comparator<BookWithStyle> comp = Comparator.comparing(BookWithStyle::getOldal);
			Arrays.sort(array, comp.reversed());
		} else {
			Arrays.sort(array, Comparator.comparing(BookWithStyle::getCim));
		}
		
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
		
	}
}