package hazi_feladat__09;

public class Konyv{
	private String cim;
	private String szerzo;
	private int ar;
	private int ev;
	private int oldalsz;
	private String kiado = "M�ra";
	
	//--------------------
	
	public Konyv(String cim, String szerzo, int ar, int oldalsz) {
		super();
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		this.cim = cim;
		this.szerzo = szerzo;
		this.ar = ar;
		this.oldalsz = oldalsz;
		this.ev = currentDate.getYear();
	}
	
	public Konyv(String cim, String szerzo, int oldalsz) {
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		this.cim = cim;
		this.szerzo = szerzo;
		this.ar = 2500;
		this.oldalsz = oldalsz;
		this.ev = currentDate.getYear();
	}
	
	//--------------------
	
	@Override
	public String toString() {		
		return "K�nyv c�me: " + cim + ", szerz�je: " + szerzo + ", �ra: " + ar + ", kiad�s �ve: " + ev + ", oldalainak sz�ma: " + oldalsz + ", kiad�: " + kiado;
	}
	
	//--------------------
	
	public void arNoveles(int plusz) {
		ar += plusz;
	}
	
	public String kiirKonyv() {		
		return "K�nyv c�me: " + cim + ", szerz�je: " + szerzo + ", �ra: " + ar + ", kiad�s �ve: " + ev;
	}
	
	//----------Getterek, Setterek----------
	
	public String getCim() {
		return cim;
	}

	public void setCim(String cim) {
		this.cim = cim;
	}

	public int getAr() {
		return ar;
	}

	public void setAr(int ar) {
		this.ar = ar;
	}
	
	public String getSzerzo() {
		return szerzo;
	}

	public void setSzerzo(String szerzo) {
		this.szerzo = szerzo;
	}
	
	public int getEv() {
		return ev;
	}
	
	public void setEv(int ev) {
		this.ev = ev;
	}
	
	public int getOldal() {
		return oldalsz;
	}

	public void setOldal(int oldalsz) {
		this.oldalsz = oldalsz;
	}
	
	//Eld�nti, hogy melyiknek hosszabbak az oldalai:
	
	public Konyv melyikHosszabb(Konyv alany1, Konyv alany2) {
		if (alany1.oldalsz > alany2.oldalsz) {
			return alany1;
		} else {
			return alany2;
		}
	}
	
	//Eld�nti, hogy az oldalal sz�ma p�ros-e:
	
	public boolean parosOldal() {
		if (this.oldalsz % 2 == 0) {
			return true;
		}
		
		return false;
	}
}
