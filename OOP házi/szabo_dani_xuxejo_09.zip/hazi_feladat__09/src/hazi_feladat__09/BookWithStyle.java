package hazi_feladat__09;

import hazi_feladat__09.BookStyle;

public class BookWithStyle extends Konyv {	
	private BookStyle style;
	
	//Konstruktor:
	
	public BookWithStyle(String cim, String szerzo, int ar, int oldalsz, BookStyle style) {
		super(cim, szerzo, ar, oldalsz);
		this.style = style;
	}
	
	//Met�dusok:
	
	@Override
	public String toString() {
		return super.toString() + ", St�lus: " + style;
	}
	
	//Getter met�dus:
	
	public BookStyle getBookStyle() {
		return style;
	}
}
