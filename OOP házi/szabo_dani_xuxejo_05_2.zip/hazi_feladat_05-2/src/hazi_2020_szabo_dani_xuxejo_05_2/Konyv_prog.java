package hazi_2020_szabo_dani_xuxejo_05_2;

import java.util.Scanner;

public class Konyv_prog {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Adja meg a k�nyv adatait!");

		// --Adatok bevitele--

		System.out.println("K�nyv c�me: ");
		String cim = input.nextLine();

		System.out.println("K�nyv szerz�je: ");
		String szerzo = input.nextLine();

		System.out.println("K�nyv �ra (ha nem tud kital�lni egy �rat, csak �ss�n be 0-�t!): ");
		int ar = 0;

		do {
			System.out.println("Csak pozit�v sz�mot adhat meg / vagy null�t az alap �rt�kekhez!");
			while (!input.hasNextInt()) {
				System.out.println("Ez nem egy sz�m!");
				input.next();
			}

			ar = input.nextInt();

		} while (ar < 0);

		System.out.println("K�nyv kiad�s�nak �ve (ha nem tud kital�lni egy �vet, csak �ss�n be 0-�t!): ");
		int ev = input.nextInt();

		if (ar == 0 && ev == 0) {
			Konyv ezKonyv = new Konyv(cim, szerzo);
			System.out.println(ezKonyv.toString());
		} else if (ar == 0) {
			Konyv ezKonyv = new Konyv(cim, szerzo, ev);
			System.out.println(ezKonyv.toString());
		} else if (ev == 0) {
			Konyv ezKonyv = new Konyv(ar, cim, szerzo);
			System.out.println(ezKonyv.toString());
		} else {
			Konyv ezKonyv = new Konyv(cim, szerzo, ar, ev);
			System.out.println(ezKonyv.toString());
		}

		input.close();
	}

}
