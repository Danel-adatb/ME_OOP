package hazi_2020_szabo_dani_xuxejo_05_2;

public class Konyv {
	private String cim;
	private String szerzo;
	private int ar;
	private int ev;
	
	//--------------------
	
	public Konyv(String cim, String szerzo, int ar, int ev) {
		super();
		this.cim = cim;
		this.szerzo = szerzo;
		this.ar = ar;
		this.ev = ev;
	}
	
	public Konyv(String cim, String szerzo) {
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		this.cim = cim;
		this.szerzo = szerzo;
		this.ar = 2500;
		this.ev = currentDate.getYear();
	}
	
	public Konyv(String cim, String szerzo, int ev) {
		
		this.cim = cim;
		this.szerzo = szerzo;
		this.ar = 2500;
		this.ev = ev;
	}
	
	public Konyv(int ar ,String cim, String szerzo) {
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		this.cim = cim;
		this.szerzo = szerzo;
		this.ar = ar;
		this.ev = currentDate.getYear();
	}
	
	//--------------------
	
	@Override
	public String toString() {
		if (ev < 0) {
			ev = ev*-1;
			return "K�nyv c�me: " + cim + ", szerz�je: " + szerzo + ", �ra: " + ar + ", kiad�s �ve: Krisztus el�tt " + ev;
		}
		
		return "K�nyv c�me: " + cim + ", szerz�je: " + szerzo + ", �ra: " + ar + ", kiad�s �ve: " + ev;
	}
	
	//--------------------
	
	public void arNoveles(int plusz) {
		ar += plusz;
	}
	
	public String kiirKonyv() {
		if (ev < 0) {
			ev = ev*-1;
			return "K�nyv c�me: " + cim + ", szerz�je: " + szerzo + ", �ra: " + ar + ", kiad�s �ve: Krisztus el�tt " + ev;
		}
		
		return "K�nyv c�me: " + cim + ", szerz�je: " + szerzo + ", �ra: " + ar + ", kiad�s �ve: " + ev;
	}
	
	//----------Getterek, Setterek----------
	
	public String getCim() {
		return cim;
	}

	public void setCim(String cim) {
		this.cim = cim;
	}

	public long getAr() {
		return ar;
	}

	public void setAr(int ar) {
		this.ar = ar;
	}
	
	public long getSzerzo() {
		return ar;
	}

	public void setSzerzo(String szerzo) {
		this.szerzo = szerzo;
	}
	
	public int getEv() {
		return ev;
	}
	
	public void setEv(int ev) {
		this.ev = ev;
	}
}
