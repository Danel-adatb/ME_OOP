package futtathato;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import xuxejo.Diak;
import xuxejo.Kurzus;

public class Test {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		Diak diak = null;
		String id = "313A";
		Kurzus kurzus = new Kurzus(id);
		int n = ellenorzottInt();
		File file = new File("hiany.txt");
		FileWriter fw = null;
		
		for (int i = 0; i < n; i++) {
				System.out.println("Adja meg a(z) "+ (i+1) +" nevet:");
				String nev = input.nextLine();
				diak = new Diak(nev);
				
				//Reg:
				kurzus.regisztral(diak);
				kurzus.setSorszam(kurzus.getSorszam() + 1);
				
				//Pontok
				diak.setPontszam(kurzus.pontoz(100));
				if (diak.getPontszam() < 50) {
					System.out.println("50% alatti: Igen\n" + diak.toString() + "\n");
				} else {
					System.out.println("50% alatti: Nem");
				}
				
				//Fileba kiirats
				try {
					fw = new FileWriter(file);
						if (diak.getPontszam() > 1 ) {
							fw.write(diak.toString() + "\n");
						}
					fw.close();
				} catch (IOException e) {
					e.getMessage();
				}
				
		}

		ABCSort(kurzus.getNevsor());
		
		
		input.close();
	}
	
	public static int ellenorzottInt() {
		Scanner input = new Scanner(System.in);
		int n;
		
		do {
			System.out.println("H�ny darab adatot szeretne beolvasni?");
			while (!input.hasNextInt()) {
				System.out.println("Ez nem egy sz�m!");
				input.next();
			}
			n = input.nextInt();
		} while(n <= 0);
		
		return n;
	}

	public static void ABCSort(ArrayList<Diak> nevsor) {
		Collections.sort(nevsor);
		System.out.println("\nSorbarendez�s ut�n:");
		for (Diak i : nevsor) {
			System.out.println(i.toString());
		}
	}

}
