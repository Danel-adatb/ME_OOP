package xuxejo;

public class Diak implements Comparable<Diak>{
	private String azonosito;
	private String nev;
	private int pontszam;
	
	public Diak(String nev) {
		this.nev = nev;
	}
	public String getNev() {
		return nev;
	}
	
	public String getAzonosito() {
		return azonosito;
	}
	
	public int getPontszam() {
		return pontszam;
	}
	
	public void setAzonosito(String azonosito) {
		this.azonosito = azonosito;
	}
	
	public void setPontszam(int pontszam) {
		this.pontszam = pontszam;
	}
	
	@Override
	public String toString() {
		return "Azonos�t�: " + this.azonosito + ", N�v: " + this.nev + ", Pontsz�m: " + this.pontszam;
	}
	
	@Override
	public int compareTo(Diak o) {
		return getNev().compareTo(o.getNev());
	}
	
}
