package xuxejo;

import java.util.Random;
import java.util.ArrayList;

public class Kurzus {
	private String kurzusAzonosito;
	private static int sorszam = 100;
	private ArrayList<Diak> nevsor = new ArrayList<Diak>();
	
	public Kurzus(String kurzusAzonosito) {
		this.kurzusAzonosito = kurzusAzonosito;
	}
	
	public int getSorszam() {
		return sorszam;
	}
	
	public void setSorszam(int sorszam) {
		this.sorszam = sorszam;
	}
	
	/*a.)*/
	public ArrayList<Diak> getNevsor() {
		return nevsor;
	}
	
	/*b.)*/
	public void regisztral(Diak o) {
		String id = "313B_" + getSorszam();
		o.setAzonosito(id);
		
		nevsor.add(o);
		
	}
	
	public int pontoz(int maxPont) {
		Random random = new Random();
		maxPont = random.nextInt(maxPont) + 1 - 3;
	
		return maxPont;
		
	}
	
	
}
