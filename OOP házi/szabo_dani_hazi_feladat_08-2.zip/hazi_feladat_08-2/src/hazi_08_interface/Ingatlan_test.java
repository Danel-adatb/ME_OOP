package hazi_08_interface;

import java.util.Scanner;

public class Ingatlan_test {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n, dont = 0;
		
		do {
			System.out.println("H�ny darab Ingatlant szeretne beolvasni?");
			while (!input.hasNextInt()) {
				System.out.println("Ez nem egy sz�m!");
				input.next();
			}
			n = input.nextInt();
		} while(n < 1);
		
		Ingatlan[] ingatlan = new Ingatlan[n];

		System.out.println("Az �r eld�nt�s�hez �ss�n le 1-est, ha forintban, 0-�t ha eur�ban szeretne dolgozni!");
		dont = input.nextInt();
		
		for (int i = 0; i < ingatlan.length; i++) {
			System.out.println((i + 1) + ". Ingatlan helye: ");
			String hely = input.next();
			System.out.println((i + 1) + ". Ingatlan �ra: ");
			double ar = input.nextInt();
			System.out.println((i + 1) + ". Ingatlan m�rete: ");
			int meret = input.nextInt();
			input.nextLine();
						
			ingatlan[i] = new Ingatlan(hely, ar, meret);
		}
		
		kiirat(ingatlan);
		Elado.ftVagyEuro(dont, ingatlan);
		//ftVagyEuro(dont, ingatlan);
		System.out.println("\n�tv�lt�s ut�n:");
		kiirat(ingatlan);
		
	}
	
	/*public static void ftVagyEuro(int dont, Ingatlan[] ingatlan) {
		double atvalt;
		int forintvalto = 355;
		
		for (Ingatlan i : ingatlan) {
			if (dont == 1) {
				i.setDeviza("Ft");
				atvalt = i.getAr() / forintvalto;
				i.setAr(atvalt);
				i.setDeviza("Euro");
				
			} else if (dont == 0) {
				i.setDeviza("Euro");
				atvalt = i.getAr() * forintvalto;
				i.setAr(atvalt);
				i.setDeviza("Ft");
			}
		}
	}*/
	
	public static void kiirat(Ingatlan[] ingatlan) {
		for (Ingatlan i : ingatlan) {
			System.out.println(i.toString());
		}
	}

}
