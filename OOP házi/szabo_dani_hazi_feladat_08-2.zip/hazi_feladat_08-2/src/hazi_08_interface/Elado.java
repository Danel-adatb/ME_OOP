package hazi_08_interface;

public interface Elado {

	public static final double ar = 1;
	public static final String deviza = "Ft";
	
	public default double getAr() {
		return ar;
	}
	
	public default String getDeviza() {
		return deviza;
	}
	
	//-------------------
	
	static void ftVagyEuro(int dont, Ingatlan[] ingatlan) {
		double atvalt;
		int forintvalto = 355;
		
		for (Ingatlan i : ingatlan) {
			if (dont == 1) {
				i.setDeviza("Ft");
				atvalt = i.getAr() / forintvalto;
				i.setAr(atvalt);
				i.setDeviza("Euro");
				
			} else if (dont == 0) {
				i.setDeviza("Euro");
				atvalt = i.getAr() * forintvalto;
				i.setAr(atvalt);
				i.setDeviza("Ft");
			}
		}
	}
	
	//-------------------
	
	public void setAr(double ar);
	
	public void setDeviza(String deviza);
}
