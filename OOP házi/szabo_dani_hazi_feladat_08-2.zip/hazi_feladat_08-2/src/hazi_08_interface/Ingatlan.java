package hazi_08_interface;

public class Ingatlan implements Elado {
	private double ar;
	private int meret;
	private String hely;
	private String deviza = "Ft";
	
	//Konstruktor
	
	public Ingatlan(String hely, double ar, int meret) {
		this.hely = hely;
		this.ar = ar;
		this.meret = meret;
	}
	
	//Fel�l defini�l�s
	
	@Override
	public String toString() {
		return "Az ingatlan �ra: " + String.format("%.2f", ar) + " " + deviza + ", m�rete: " + meret + ", helye: " + hely;
	}
	
	public double negyzetMeter() {
		return ar / meret;
	}
	
	//---------------------
	
	public void setAr(double ar) {
		this.ar = ar;
	}
	
	public void setDeviza(String deviza) {
		this.deviza = deviza;
	}
	
	//--------------------
	
	public double getAr() {
		return ar;
	}
	
	public int getMeret() {
		return meret;
	}

	public void setMeret(int meret) {
		this.meret = meret;
	}
	
	public String getHely() {
		return hely;
	}

	public void setHely(String hely) {
		this.hely = hely;
	}
}
