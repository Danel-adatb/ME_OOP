package hazi_08_interface;

public abstract class Aru implements Elado {
	private String nev;
	private int nettoAr;
	private int afakulcs;
	private double ar;
	private String deviza;
	
	//Konstruktor: 
	
	public Aru(String nev, int nettoAr, int afakulcs, double ar, String deviza) {
		this.nev = nev;
		this.nettoAr = nettoAr;
		this.afakulcs= afakulcs;
		this.ar = ar;
		this.deviza = deviza;
	}
	
	//Abstract met�dus:
	
	public abstract int egysegAr();
	
	//interfave implement�l�sa
	
	public void setAr(double ar) {
		this.ar = ar;
	}
	
	public void setDeviza(String deviza) {
		this.deviza = deviza;
	}
	
	//--------------------
	
	@Override
	public String toString() {
		return "�ru n�v: " + nev + ", Brutt� �r: " + getArAfaval() + ", Nett� �r: " + nettoAr + ", Alap�rtelmezett �ra: " + ar + " " + deviza;
	}
	
	public int getArAfaval() {
		return nettoAr + (nettoAr*afakulcs);
	}
	
	public double nettoArNoveles(int szazalek) {
		return nettoAr + (nettoAr * szazalek / 100);
	}
	
	public int ArVagyAfa(Aru p) {
		if (this.getArAfaval() > p.getArAfaval()) {
			return 1;
		}
		
		if (this.getArAfaval() == p.getArAfaval()) {
			return 0;
		}
		
		return -1;
	}
	
	//Getterek, setterek:
	
	public String getNev() {
		return nev;
	}

	public void setnev(String nev) {
		this.nev = nev;
	}

	public int getNettoAr() {
		return nettoAr;
	}
	
	public void setNettoAr(int nettoAr) {
		this.nettoAr = nettoAr;
	}
	
	public int getAfakulcs() {
		return afakulcs;
	}
	
	public void setAfakulcs(int afakulcs) {
		this.afakulcs = afakulcs;
	}
	
}