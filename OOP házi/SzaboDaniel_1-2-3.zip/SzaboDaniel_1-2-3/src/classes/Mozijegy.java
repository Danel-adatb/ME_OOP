package classes;

import java.time.LocalDate;

public class Mozijegy extends Jegy {
	private String filmCim;
	private int terem;
	private int alapar = 1000;
	
	public Mozijegy(String filmCim, int terem, LocalDate date, EnumJegy jegy) {
		super(date, jegy);
		
		this.filmCim = filmCim;
		this.terem = terem;
	}
	
	public Mozijegy(String filmCim, int terem, LocalDate date) {
		super(date,EnumJegy.TELJESARU);
		
		this.filmCim = filmCim;
		this.terem = terem;
	}
	
	public String getFilm() {
		return filmCim;
	}
	
	public int getTerem() {
		return terem;
	}
	
	public int getAlapar() {
		return alapar;
	}
	
	public void setFilm(String filmCim) {
		this.filmCim = filmCim;
	}
	
	public void setTerem(int terem) {
		this.terem = terem;
	}
	
	public void setAlapar(int alapar) {
		this.alapar = alapar;
	}
	
	public void hetvege() {
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		if (currentDate.getDayOfWeek().name() == "FRIDAY" || currentDate.getDayOfWeek().name() == "SATURDAY" || currentDate.getDayOfWeek().name() == "SUNDAY") {
			setJegy(EnumJegy.FELARAS);
		}
	}
	
	public double jegyArak() {
		return this.alapar * jegyFaktor();
	}
	
	@Override
	public String toString() {
		return super.toString() + ", Film c�me: " + this.filmCim + ", terem: " + this.terem + ", Jegy �ra: " + jegyArak();
	}

	
}
