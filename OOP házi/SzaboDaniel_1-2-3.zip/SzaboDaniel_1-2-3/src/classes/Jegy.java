package classes;

import java.time.LocalDate;

public class Jegy implements Comparable<Jegy>{
	private LocalDate date;
	private EnumJegy jegy;
	
	public Jegy(LocalDate date, EnumJegy jegy) {
		this.date = date;
		this.jegy = jegy;
	}
	
	@Override
	public String toString() {
		return "D�tum: " + this.date + ", Jegy: " + this.jegy;
	}
	
	//Getterek
	
	public LocalDate getDate() {
		return date;
	}
	
	public EnumJegy getJegy() {
		return jegy;
	}
	
	//Setter
	
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	public void setJegy(EnumJegy jegy) {
		this.jegy = jegy;
	}
	
	public double jegyFaktor() {
		double faktor = 0;
		
		if (this.jegy == EnumJegy.DIAK) {
			faktor = 0.5;
		} else if(this.jegy == EnumJegy.FELARAS) {
			faktor = 1.25;
		} else if(this.jegy == EnumJegy.TELJESARU) {
			faktor = 1;
		}
		
		return faktor;
	}
	
	@Override
	public int compareTo(Jegy o) {
		return getDate().compareTo(o.getDate());
	}
}
