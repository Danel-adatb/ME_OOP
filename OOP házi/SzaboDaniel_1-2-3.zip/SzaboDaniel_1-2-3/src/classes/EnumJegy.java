package classes;

public enum EnumJegy {
	DIAK, TELJESARU, FELARAS;
}
