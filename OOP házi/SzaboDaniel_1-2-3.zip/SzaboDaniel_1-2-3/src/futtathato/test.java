package futtathato;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

import classes.EnumJegy;
import classes.Mozijegy;

public class test {

	public static void main(String[] args) {
		ArrayList<Mozijegy> tomb = new ArrayList<Mozijegy>();
		int n = 5;
		
		for (int i = 0; i < n; i++) {
			tomb.add(getDatas());
		}
		
		masodik(tomb);
		sort(tomb);
		bevetel(tomb);
		

	}
	
	public static Mozijegy getDatas() {
		InputStreamReader instream = new InputStreamReader(System.in);
		BufferedReader input = new BufferedReader(instream);
		
		Mozijegy tomb = null;
		
		String strng;
		boolean ok = true;
		do {
			try {
				ok = true;
				System.out.println("C�m: ");
				String cim = input.readLine();
				System.out.println("terem: ");
				int terem = Integer.valueOf(input.readLine());
				
				LocalDate now = LocalDate.now();
				
				System.out.println("datum: ");
				String dateUnformed = input.readLine();
				LocalDate date = LocalDate.parse(dateUnformed);
				while (date.isAfter(now)) {
					System.out.println("�rv�nytelen D�tum!");
					dateUnformed = input.readLine();
					date = LocalDate.parse(dateUnformed);
				}
				
				
				System.out.println("jegy tipus: ");
				strng = input.readLine();
				EnumJegy jegy = EnumJegy.valueOf(strng.toUpperCase());
				
				tomb = new Mozijegy(cim, terem, date, jegy);
				
			} catch(IllegalArgumentException e) {
				System.out.println("Nem l�tez� Jegy!");
				ok = false;
			} catch(IOException e) {
				System.out.println(e.getMessage());
			}
		} while(!ok);
		
		return tomb;
	}

	public static void masodik(ArrayList<Mozijegy> tomb) {
		int count=0;
		for (Mozijegy i : tomb) {
			if (i.getJegy() == EnumJegy.FELARAS) {
				count++;
			}
		}
		
		System.out.println(count + " db F�l�ras jegyet adtak el!");
	}
	
	public static void sort(ArrayList<Mozijegy> tomb) {
		Collections.sort(tomb);
		System.out.println("\nSorbarendez�s ut�n:");
		for (Mozijegy i : tomb) {
			System.out.println(i.toString());
		}
	}

	public static void bevetel(ArrayList<Mozijegy> tomb) {
		double temp;
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		for (Mozijegy i : tomb) {
			if(currentDate.getMonth().equals("MAY")) {
				System.out.println("Mozi bev�tele: " + i.jegyArak());
			}
		}
	}
}
