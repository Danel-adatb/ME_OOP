package hazi_2020_szabo_dani_xuxejo_05_1;

import java.util.Scanner;

public class alkalmazott_prog {

	public static void main(String[] args) {
		alkalmazott tomb[] = new alkalmazott[3];
		Scanner input = new Scanner(System.in);
		
		
		System.out.println("Adja meg az alkalmazottak nev�t �s fizet�s�t");
		System.out.println("(Alap fizet�shez �rjon be 0-�t)");
		
		//Adatok bevitele:
		
			for (int i = 0; i < tomb.length; i++) {
				
				System.out.println((i+1) + ". Szem�ly neve: ");
				String nev = input.nextLine();
				System.out.println((i+1) + ". Szem�ly fizet�se: ");
				
				long fizetes = input.nextLong();
				input.nextLine();
				
					if (fizetes == 0) {
						tomb[i] = new alkalmazott(nev);
					} else {
						tomb[i] = new alkalmazott(nev, fizetes);
					}
			}
		
		listArray(tomb);
		
		System.out.println("Legnagyobb fizet�s� alk.: " + tomb[maxFizetes(tomb)].getNev());
		
		input.close();
	}

	//----------Legnagyobb fizet�s function:----------
	
	public static int maxFizetes(alkalmazott[] tombAlk) {
		int maxindex = 0;
		for (int i = 0; i < tombAlk.length; i++) {
			if (tombAlk[maxindex].getFizetes() < tombAlk[i].getFizetes()) {
				maxindex = i;
			}
		}
		return maxindex;
	}
	
	//-------------------------------------------------------------------------

	static void listArray(alkalmazott[] tombAlk) {
		
		for (alkalmazott eszkoz : tombAlk) {
			System.out.println(eszkoz.toString());
		}
	}
}
