package hazi_2020_szabo_dani_xuxejo_05_1;

public class alkalmazott {
	private String nev;
	private long fizetes;

	//----------Konstruktor 1.----------
	
	public alkalmazott(String nev, long fizetes) {
		super();
		this.nev = nev;
		this.fizetes = fizetes;
	}

	//----------Konstruktor 2.----------
	
	public alkalmazott(String nev) {
		this(nev, 250000);
	}

	//----------Fel�l defini�l�s----------
	
	@Override
	public String toString() {
		return "Alkalmazott Neve: " + this.nev + ", Fizet�se: " + this.fizetes;
	}

	//--------------------
	
	public void fizetesNoveles(long plusz) {
		fizetes += plusz;
	}

	public String kiirAlk() {
		return "N�v: " + nev + "," + " fizet�s: " + fizetes;
	}

	//----------Getterek, setterek----------
	
	public String getNev() {
		return nev;
	}

	public void setNev(String nev) {
		this.nev = nev;
	}

	public long getFizetes() {
		return fizetes;
	}

	public void setFizetes(long fizetes) {
		this.fizetes = fizetes;
	}

	//----------Fizet�s, ad�, nagyobb-e a fizet�sn�l----------
	
	public boolean fizetesIntervallum(long also, long felso) {
		if (fizetes <= felso && fizetes >= also) {
			return true;
		}
		
		return false;
	}

	public long getAdo(int adoMertek) {
		return Math.round(fizetes * adoMertek / 100);
	}

	public boolean fizetesNagyobbMint(alkalmazott alk) {
		if (this.fizetes > alk.fizetes) {
			return true;
		}
		
		return false;
	}

}
