package hazi_feladat_07_xuxejo;

public class adult extends mypersons{
	private String job;
	
	public adult(String name, int age, String job) {
		super(name, age);
		this.job = job;
	}
	
	//toString fel�l defini�l�sa:
	
	@Override
	public String toString() {
		return super.toString() + ", Munkahely neve: " + job;
	}
	
	//Getter:
	
	public String getJob() {
		return job;
	}
	
	//Setterek
	
	public void setJob(String job) {
		this.job = job;
	}
}
