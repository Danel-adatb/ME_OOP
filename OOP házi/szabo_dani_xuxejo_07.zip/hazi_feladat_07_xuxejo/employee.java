package hazi_feladat_07_xuxejo;

public class employee extends adult{
	private long payment;
	private final int retirement = 65;
	
	public employee(String name, int age, String job, long payment) {
		super(name, age, job);
		this.payment = payment;
	}
	
	//toString fel�l defini�l�sa
	
	@Override
	public String toString() {
		return super.toString() + ", Fizet�se: " + payment;
	}
	
	//Fizet�st adja vissza:
	
	public long getPayment() {
		return payment;
	}
	
}
