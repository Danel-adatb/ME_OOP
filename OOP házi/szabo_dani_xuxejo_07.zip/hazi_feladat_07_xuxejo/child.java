package hazi_feladat_07_xuxejo;

public class child extends mypersons {
	private String school;
	
	//Konstruktor:
	
	public child(String name, int age, String school) {
		super(name, age);
		this.school = school;
	}
	
	//toString fel�l defini�l�sa:
	
	@Override
	public String toString() {
		return super.toString() + ", Iskolva neve: " + school;
	}
	
	//Getter:
	
	public String getSchool() {
		return school;
	}
}
