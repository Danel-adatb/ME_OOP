package hazi_feladat_07_xuxejo;

public class mypersons {
	private String name;
	private int age;
	
	//Konstruktor:
	
	public mypersons(String name, int age) {
		super();
		
		this.name = name;
		this.age = age;
	}
	
	//Setterek:

	public void setName(String name) {
		this.name = name;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	//Getterek:
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	//String �sszef�z�s:
	
	@Override
	public String toString() {
		return "A szem�ly neve: " + name + ", kora: " + age;
	}
	
	//Ha a param�terben adott korn�l kisebb:
	
	public boolean lowerThan(int param) {
		if (this.age < param) {
			return true;
		}
		
		return false;
	}
}
