package hazi_feladat_07_xuxejo.test;

import java.util.Scanner;
import hazi_feladat_07_xuxejo.*;

public class mypersons_test {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = 2;
		int param = 18;

		mypersons[] person = new mypersons[n];
				
		getDatas(person, param);
		System.out.println();
		outputDatas(person);
		
		input.close();

	}
	
	public static void getDatas(mypersons[] person, int param) {
		Scanner input = new Scanner(System.in);
		
		for (int i = 0; i < person.length; i++) {
			System.out.println((i + 1) + ". szem�ly neve: ");
			String name = input.nextLine();
			System.out.println((i + 1) + ". szem�ly kora: ");
			int age = input.nextInt();
			input.nextLine();
		
			person[i] = new mypersons(name, age);
			
			if(person[i].lowerThan(param)) {
				System.out.println("Adja meg " + name + " iskol�j�t:");
				String school = input.nextLine();
				
				person[i] = new child(name, age, school);
				System.out.print("Objektum tipusa mypersons-e: ");
				System.out.println(person[i] instanceof mypersons);
			} else {
				System.out.println("adja meg " + name + " munkahely�t:");
				String job = input.nextLine();
				
				person[i] = new adult(name, age, job);
				System.out.print("Objektum tipusa mypersons-e: ");
				System.out.println(person[i] instanceof mypersons);
			}
		}
	}
	
	public static void outputDatas(mypersons[] person) {
		
		for (mypersons i : person) {
			System.out.println(i.toString());
		}
	}
}
