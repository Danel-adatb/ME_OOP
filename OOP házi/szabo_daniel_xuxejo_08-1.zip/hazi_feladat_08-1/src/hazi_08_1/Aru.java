package hazi_08_1;

public abstract class Aru {
	private String nev;
	private int nettoAr;
	private int afakulcs;
	
	//Konstruktor: 
	
	public Aru(String nev, int nettoAr, int afakulcs) {
		super();
		this.nev = nev;
		this.nettoAr = nettoAr;
		this.afakulcs= afakulcs;
	}
	
	//Abstract met�dus:
	
	public abstract int egysegAr();
	
	//--------------------
	
	@Override
	public String toString() {
		return "�ru n�v: " + nev + ", Brutt� �r: " + getArAfaval() + ", Nett� �r: " + nettoAr;
	}
	
	public int getArAfaval() {
		return nettoAr + (nettoAr*afakulcs);
	}
	
	public double nettoArNoveles(int szazalek) {
		return nettoAr + (nettoAr * szazalek / 100);
	}
	
	public int ArVagyAfa(Aru p) {
		if (this.getArAfaval() > p.getArAfaval()) {
			return 1;
		}
		
		if (this.getArAfaval() == p.getArAfaval()) {
			return 0;
		}
		
		return -1;
	}
	
	//Getterek, setterek:
	
	public String getNev() {
		return nev;
	}

	public void setnev(String nev) {
		this.nev = nev;
	}

	public int getNettoAr() {
		return nettoAr;
	}
	
	public void setNettoAr(int nettoAr) {
		this.nettoAr = nettoAr;
	}
	
	public int getAfakulcs() {
		return afakulcs;
	}
	
	public void setAfakulcs(int afakulcs) {
		this.afakulcs = afakulcs;
	}
	
}