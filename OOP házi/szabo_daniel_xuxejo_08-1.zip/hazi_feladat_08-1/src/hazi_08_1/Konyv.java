package hazi_08_1;

public class Konyv extends Aru{
	private String szerzo;
	private int ev;
	private int oldalsz;
	private String kiado = "M�ra";
	
	//--------------------
	
	public Konyv(String nev, String szerzo, int oldalsz, int nettoAr, int afakulcs) {
		super(nev, nettoAr, afakulcs);
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		this.szerzo = szerzo;
		this.oldalsz = oldalsz;
		this.ev = currentDate.getYear();
	}
	
	public Konyv(String nev, String szerzo, int oldalsz, int afakulcs) {
		super(nev, 2500, afakulcs);
		java.time.LocalDate currentDate = java.time.LocalDate.now();
		
		this.szerzo = szerzo;
		this.oldalsz = oldalsz;
		this.ev = currentDate.getYear();
	}
	//--------------------
	
	@Override
	public String toString() {		
		return super.toString() + " Szerz�: " + szerzo + ", Kiad�si �v: " + ev + ", Oldalak sz�ma: " + oldalsz + ", Kiad�: " + kiado + ", Egys�g�r: " + this.egysegAr();
	}
	
	@Override
	public int egysegAr() {
		return this.getArAfaval()/oldalsz;
	}
	
	//Eld�nti, hogy melyiknek hosszabbak az oldalai:
	
	public Konyv melyikHosszabb(Konyv alany1, Konyv alany2) {
		if (alany1.oldalsz > alany2.oldalsz) {
			return alany1;
		} else {
			return alany2;
		}
	}
	
	//----------Getterek, Setterek----------
	
	public String getSzerzo() {
		return szerzo;
	}
	
	public void setSzerzo(String szerzo) {
		this.szerzo = szerzo;
	}
	
	public int getOldalsz() {
		return oldalsz;
	}
	
	public void setOldalsz(int oldalsz) {
		this.oldalsz = oldalsz;
	}
	
	public int getEv() {
		return ev;
	}
	
	public void setEv(int ev) {
		this.ev = ev;
	}
	
	//Eld�nti, hogy az oldalal sz�ma p�ros-e:
	
	public boolean parosOldal() {
		if (this.oldalsz % 2 == 0) {
			return true;
		}
		
		return false;
	}
}