package hazi_08_1;

import java.util.ArrayList;
import java.util.Scanner;

public class aru_test {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n;
		
		do {
			System.out.println("H�ny darab K�nyvet szeretne beolvasni?");
			while (!input.hasNextInt()) {
				System.out.println("Ez nem egy sz�m!");
				input.next();
			}
			n = input.nextInt();
		} while(n < 1);
		
		Konyv[] konyvek = new Konyv[n];
		
		getDatas(konyvek);
		outputDatas(konyvek);
		outputDatasFromMin(konyvek);
		
		System.out.println("\n20-n�l nagyobb egys�g�r� k�nyvek szerz�i: ");
		egysegArnagyobbMint(konyvek);

	}
	
	public static void getDatas(Konyv[] konyvek) {
		Scanner input = new Scanner(System.in);
		
		for (int i = 0; i < konyvek.length; i++) {
			System.out.println((i + 1) + ". K�nyv neve: ");
			String nev = input.nextLine();
			System.out.println((i + 1) + ". K�nyv szerz�je: ");
			String szerzo = input.nextLine();
			System.out.println((i + 1) + ". K�nyv oldalsz�ma: ");
			int oldalsz = input.nextInt();
			System.out.println((i + 1) + ". K�nyv �ra (nett�): ");
			int nettoAr = input.nextInt();
			System.out.println((i + 1) + ". K�nyv �fakulcsa: ");
			int afakulcs = input.nextInt();
			input.nextLine();
		
			konyvek[i] = new Konyv(nev, szerzo, oldalsz, nettoAr, afakulcs);
		}
	}
	
	public static void outputDatas(Konyv[] konyvek) {
		
		for (Konyv i : konyvek) {
			System.out.println(i.toString());
		}
	}
	
	public static void outputDatasFromMin(Konyv[] konyvek) {
		
		Konyv temp;
		int min;
		
		for (int i = 0; i < konyvek.length-1; i++) {
			min = i;
			
			for (int j = i + 1; j < konyvek.length; j++) {
				if (konyvek[j].egysegAr() < konyvek[min].egysegAr()) {
					min = j;
				}
			}
			
			if (min != i) {
				temp = konyvek[i];
				konyvek[i] = konyvek[min];
				konyvek[min] = temp;
			}
		}
		
		System.out.println("\nRendezett sor:");
		for (Konyv i : konyvek) {
			System.out.println(i.toString());
		}
	}
	
	private static void egysegArnagyobbMint(Konyv[] konyvek) {
		ArrayList<String> vizsgaltSzerzo = new ArrayList<String>();
		for (Konyv konyv : konyvek) {
			String szerzo = konyv.getSzerzo();
			if (!vizsgaltSzerzo.contains(szerzo)) {
				if (konyv.egysegAr() > 20) {
					vizsgaltSzerzo.add(szerzo);
					System.out.println("Szerz�: " + szerzo);
				}
			}
		}
	}
}
